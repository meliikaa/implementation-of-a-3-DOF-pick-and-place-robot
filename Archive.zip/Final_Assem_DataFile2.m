% Simscape(TM) Multibody(TM) version: 7.4

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(11).translation = [0.0 0.0 0.0];
smiData.RigidTransform(11).angle = 0.0;
smiData.RigidTransform(11).axis = [0.0 0.0 0.0];
smiData.RigidTransform(11).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [32 0 -17.499999999999989];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[upper_base-1:-:surface_bellbearing-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-32.000000000000014 -17.500000000000036 40.000000000000028];  % mm
smiData.RigidTransform(2).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(2).axis = [-1 -0 -0];
smiData.RigidTransform(2).ID = 'F[upper_base-1:-:surface_bellbearing-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-79.486427888896486 158.25914679223271 -50];  % mm
smiData.RigidTransform(3).angle = 0;  % rad
smiData.RigidTransform(3).axis = [0 0 0];
smiData.RigidTransform(3).ID = 'B[3tai-1:-:Link2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-8.0149220593739301e-12 -41.885232007453908 45.000000000000711];  % mm
smiData.RigidTransform(4).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(4).axis = [-1 -1.2934510951194637e-32 2.5227377852986609e-17];
smiData.RigidTransform(4).ID = 'F[3tai-1:-:Link2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [0 10.000000000000009 0];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[upper_base-1:-:3tai-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-96.03642788890096 41.728547100338943 -20.000000000000696];  % mm
smiData.RigidTransform(6).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(6).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962562];
smiData.RigidTransform(6).ID = 'F[upper_base-1:-:3tai-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 165.11476799255243 0];  % mm
smiData.RigidTransform(7).angle = 0;  % rad
smiData.RigidTransform(7).axis = [0 0 0];
smiData.RigidTransform(7).ID = 'B[Link2-1:-:Link3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [5.4308295697623681 20.000000000000441 36.335631091046153];  % mm
smiData.RigidTransform(8).angle = 2.0943951023931939;  % rad
smiData.RigidTransform(8).axis = [-0.57735026918962529 -0.5773502691896274 -0.57735026918962462];
smiData.RigidTransform(8).ID = 'F[Link2-1:-:Link3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 9.9999999999999947 -95];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[down_base-1:-:upper_base-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [1.6186163520615082e-11 -99.999999999999957 -95];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(10).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(10).ID = 'F[down_base-1:-:upper_base-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [99.903078637029324 97.600563675736211 167.77856469016203];  % mm
smiData.RigidTransform(11).angle = 0;  % rad
smiData.RigidTransform(11).axis = [0 0 0];
smiData.RigidTransform(11).ID = 'RootGround[down_base-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(6).mass = 0.0;
smiData.Solid(6).CoM = [0.0 0.0 0.0];
smiData.Solid(6).MoI = [0.0 0.0 0.0];
smiData.Solid(6).PoI = [0.0 0.0 0.0];
smiData.Solid(6).color = [0.0 0.0 0.0];
smiData.Solid(6).opacity = 0.0;
smiData.Solid(6).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.091493029156253597;  % kg
smiData.Solid(1).CoM = [0 72.804879914664014 13.845470197330032];  % mm
smiData.Solid(1).MoI = [683.75641157242853 18.813148048302853 683.77366458241841];  % kg*mm^2
smiData.Solid(1).PoI = [8.7581956915308048 0 0];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Link2*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.2133476100383058;  % kg
smiData.Solid(2).CoM = [-93.924548074421821 92.557849027200376 -18.892244259937328];  % mm
smiData.Solid(2).MoI = [509.06847257621143 261.55052222396398 500.24292426122435];  % kg*mm^2
smiData.Solid(2).PoI = [-13.138059773125843 -3.3800544209258732 -48.115880858615299];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = '3tai*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.37672251225888503;  % kg
smiData.Solid(3).CoM = [0 5.0074302940845348 9.9704109705868851e-13];  % mm
smiData.Solid(3).MoI = [1148.3115578596794 2289.9799360664497 1147.9507773593409];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'upper_base*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.012973996182490765;  % kg
smiData.Solid(4).CoM = [5.4308295697647164 4.9999999999999991 -12.850040036795008];  % mm
smiData.Solid(4).MoI = [13.654657275998609 13.824929742082983 0.38650573579255376];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Link3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.10891464639517043;  % kg
smiData.Solid(5).CoM = [0 0 20.795134292322455];  % mm
smiData.Solid(5).MoI = [40.221125765367127 43.909535515197994 54.464449011166373];  % kg*mm^2
smiData.Solid(5).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'surface_bellbearing*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.37423280008090754;  % kg
smiData.Solid(6).CoM = [5.7831976181289975e-13 5.0234717348601006 -0.047325431072582212];  % mm
smiData.Solid(6).MoI = [1132.9266995370692 2260.8024944827557 1134.1243077913632];  % kg*mm^2
smiData.Solid(6).PoI = [-0.025532734791661852 0 0];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'down_base*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(4).Rz.Pos = 0.0;
smiData.RevoluteJoint(4).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 89.999999999999986;  % deg
smiData.RevoluteJoint(1).ID = '[upper_base-1:-:surface_bellbearing-1]';

smiData.RevoluteJoint(2).Rz.Pos = -155.69626390697675;  % deg
smiData.RevoluteJoint(2).ID = '[3tai-1:-:Link2-1]';

smiData.RevoluteJoint(3).Rz.Pos = 19.446344315206105;  % deg
smiData.RevoluteJoint(3).ID = '[upper_base-1:-:3tai-1]';

smiData.RevoluteJoint(4).Rz.Pos = -74.36530825195085;  % deg
smiData.RevoluteJoint(4).ID = '[Link2-1:-:Link3-1]';

